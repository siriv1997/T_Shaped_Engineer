A Pen created at CodePen.io. You can find this one at https://codepen.io/drewdrewthis/pen/KzWPWP.

 Mostly finished. Works on taking existing repo and separating concerns.